package com.example.teamleadapp.data.remote;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface GithubService {
    @GET("repos/{username}/{repoName}/commits")
    Call<List<ResponseBody>> getCommits(@Path("username") String username, @Path("repoName") String repoName);
}
